# KAIRO DIGITAL SERVICES — Android App

Native Android application built with Kotlin + Jetpack Compose.

## Project
- Application ID: com.kairo.digital.services
- Min SDK: 24
- Target SDK: 37
- Compile SDK: 37
- AGP: 9.4.0
- Kotlin: 2.4.10
- Compose BOM: 2026.09.00

## Build APK

From the project root:

./gradlew assembleDebug

Debug APK:
app/build/outputs/apk/debug/app-debug.apk

Release APK:

./gradlew assembleRelease

Release APK:
app/build/outputs/apk/release/app-release.apk

## Important
This app does not contain fake verification claims. The UI uses a premium-platform style badge, but it does not claim official verification by TikTok, CapCut, Google, or another company.

WhatsApp:
+92 305 8368960

TikTok:
https://www.tiktok.com/@aivideo2363
