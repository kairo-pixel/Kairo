@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=9.6.0"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\gradle-%GRADLE_VERSION%-bin\kairo-bootstrap"
set "DIST=%CACHE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
if exist "%DIST%" goto runGradle
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
set "ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%CACHE_DIR%'"
del /q "%ZIP%"
:runGradle
call "%DIST%" %*
endlocal
